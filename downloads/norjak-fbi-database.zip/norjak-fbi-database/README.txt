D.B. Cooper (NORJAK) FBI files: searchable SQLite database
From Thoughts in the Vortex, thoughtsinthevortex.com

dbcooper.db holds the OCR text of all 44,238 pages in the FBI Vault D.B. Cooper release (122 parts),
with a full-text index. search.py is a small command-line search tool (Python 3, no extra packages):

  python3 search.py "parachute Cossey"        ranked keyword search
  python3 search.py '"Tena Bar"'              exact phrase
  python3 search.py 'money NEAR/10 serial'    words near each other
  python3 search.py -f "Sannel"               sound-alike (spelling variants, OCR misreads)
  python3 search.py --page 11 16              full text of Part 11, PDF page 16

Tables: parts(part, file_name, vault_item, vault_url, pages, ocr_pages);
pages(id, part, page, text, chars, bates); pages_fts (FTS5 index on pages.text); meta.
Bates numbers come from OCR of the stamp (~70% of pages) and can be off by a digit.
OCR is imperfect; check the scan on the FBI Vault before quoting.
