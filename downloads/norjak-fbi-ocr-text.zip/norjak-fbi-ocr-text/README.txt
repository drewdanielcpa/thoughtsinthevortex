D.B. Cooper (NORJAK) FBI files: searchable OCR text
From Thoughts in the Vortex, thoughtsinthevortex.com

WHAT THIS IS
The FBI's D.B. Cooper file as released on the FBI Vault (https://vault.fbi.gov/D-B-Cooper%20),
122 parts and 44,238 pages, run through OCR (Tesseract, 300 dpi) because the FBI's own text layer
is unusable. There is one text file per Vault part. Every page starts with a header line:

  ==== Part 64 · PDF page 304 · Bates DB Cooper-27170 ====

"PDF page" is the page number in the Vault PDF viewer. The Bates number is the FBI's stamp in the
bottom-right corner. It was read by OCR, so it is missing on some pages and occasionally off by a digit.

HOW TO SEARCH
Open the folder in any editor that searches across files (VS Code, Notepad++, Sublime, or Windows
search), or use grep, e.g.  grep -n "Tena Bar" *.txt
OCR is imperfect: try spelling variants, and remember that a miss doesn't prove something isn't in the
file. Always check the scan on the FBI Vault before quoting.

THE SCANS
Each text file's second line links to that part on the FBI Vault.

LIMITS
Much of the file is 1970s teletypes, carbons and handwriting. Photos, clippings and handwritten notes
often OCR poorly. Names redacted by the FBI appear as blanks or exemption codes (b6, b7C).
