#!/usr/bin/env python3
"""Search the D.B. Cooper FBI Vault OCR database.

  python3 search.py "Tena Bar"              # ranked full-text search (FTS5 syntax)
  python3 search.py '"Ariel" NEAR money'    # phrase / NEAR queries
  python3 search.py -f "Albert Sannel"      # SOUND-ALIKE search: spelling variants + OCR misreads
  python3 search.py --like "Kenneth Christ" # raw substring search
  python3 search.py --page 24 105           # print full OCR text of Part 24, page 105
  python3 search.py ... --limit 50 --part 30 # restrict to one part

A normal search that finds nothing automatically retries as a sound-alike search.

Sound-alike search (-f / --fuzzy) looks up every word in the index that could be the
word you typed: different spellings (Sannel / Sanell / Sannell), common OCR misreads
(1 for l, 0 for O, rn for m, 5 for S ...), and similar-sounding forms. With several
words, they must appear close together on the page (--window, in characters).

Each hit prints: citation (Part, PDF page, Bates), local file, FBI Vault link, snippet.
"""
import argparse, os, re, sqlite3, sys, textwrap

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "dbcooper.db")

# ------------------------------------------------------------------ citations
def cite(r):
    b = f", Bates {r['bates']}" if r["bates"] else ""
    return (f"FBI Vault, D.B. Cooper Part {r['part']}, PDF p. {r['page']}{b}  "
            f"[FBI Vault PDFs/{r['file_name']}]  {r['vault_url']}")

# ------------------------------------------------------------------ sound-alike matching
OCR_SWAPS = [("rn", "m"), ("vv", "w"), ("ii", "u"), ("0", "o"), ("1", "l"), ("|", "l"),
             ("!", "l"), ("5", "s"), ("8", "b"), ("$", "s"), ("€", "e")]

def norm(w):
    """Lower-case, undo common OCR confusions, collapse doubled letters."""
    w = w.lower()
    for a, b in OCR_SWAPS:
        w = w.replace(a, b)
    w = re.sub(r"[^a-z]", "", w)
    return re.sub(r"(.)\1+", r"\1", w)

def soundex(w):
    w = re.sub(r"[^a-z]", "", w.lower())
    if not w:
        return ""
    codes = {**dict.fromkeys("bfpv", "1"), **dict.fromkeys("cgjkqsxz", "2"),
             **dict.fromkeys("dt", "3"), "l": "4", **dict.fromkeys("mn", "5"), "r": "6"}
    out, prev = w[0].upper(), codes.get(w[0], "")
    for ch in w[1:]:
        c = codes.get(ch, "")
        if c and c != prev:
            out += c
        if ch not in "hw":
            prev = c
    return (out + "000")[:4]

def edit_distance(a, b, cap):
    """Damerau-Levenshtein distance, early exit once it exceeds cap."""
    if abs(len(a) - len(b)) > cap:
        return cap + 1
    prev2, prev = None, list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cost = a[i - 1] != b[j - 1]
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                cur[j] = min(cur[j], prev2[j - 2] + 1)
        if min(cur) > cap:
            return cap + 1
        prev2, prev = prev, cur
    return prev[-1]

_VOCAB = None
def vocab(db):
    global _VOCAB
    if _VOCAB is None:
        db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS temp.vocab USING fts5vocab(main, 'pages_fts', 'row')")
        _VOCAB = [(t, n) for t, n in db.execute("SELECT term, doc FROM temp.vocab") if t.isalpha()]
    return _VOCAB

def variants(db, word, max_variants=30):
    """Index terms that could be `word`: returns [(term, pages, distance)]."""
    w = norm(word)
    L = len(w)
    sx = soundex(w)
    found = []
    for term, n in vocab(db):
        t = norm(term)
        if t[:1] != w[:1] or abs(len(t) - L) > 2:
            continue                      # first letter must agree (OCR maps 5->s etc. first)
        if L <= 4:                        # short words: only OCR/doubled-letter variants
            d = 0 if t == w else 9
        else:
            d = edit_distance(w, t, 2)
        ok = (d == 0 or
              (L >= 5 and d == 1) or
              (L >= 8 and d == 2) or
              (5 <= L < 8 and d == 2 and t[:2] == w[:2] and abs(len(t) - L) <= 1 and soundex(t) == sx))
        if ok:
            found.append((term, n, d))
    found.sort(key=lambda x: (x[2], -x[1]))
    return found[:max_variants]

def fuzzy_search(db, words, window, part, limit):
    groups = []
    for w in words:
        v = variants(db, w)
        if not v:
            return [], groups, 0
        groups.append((w, v))
    fts = " AND ".join("(" + " OR ".join(f'"{t}"' for t, _, _ in v) + ")" for _, v in groups)
    extra = " AND pages.part=?" if part else ""
    rows = db.execute(
        "SELECT pages.*, file_name, vault_url FROM pages_fts JOIN pages ON pages.id=pages_fts.rowid "
        f"JOIN parts USING(part) WHERE pages_fts MATCH ?{extra} ORDER BY rank",
        [fts] + ([part] if part else [])).fetchall()
    # word-level regexes on the raw text (index terms are stemmed, so allow endings)
    regs = [re.compile(r"(?<![A-Za-z])(?:" + "|".join(re.escape(t) for t, _, _ in v) + r")[A-Za-z]*", re.I)
            for _, v in groups]
    hits = []
    for r in rows:
        text = r["text"]
        spans = [[m.span() for m in rg.finditer(text)] for rg in regs]
        if not all(spans):
            continue
        best = None
        for s0 in spans[0]:
            pick = [s0]
            for sp in spans[1:]:
                near = min(sp, key=lambda s: abs(s[0] - s0[0]))
                pick.append(near)
            lo, hi = min(p[0] for p in pick), max(p[1] for p in pick)
            if len(regs) == 1 or hi - lo <= window:
                best = pick
                break
        if best is None:
            continue
        lo, hi = min(p[0] for p in best), max(p[1] for p in best)
        snip = text[max(0, lo - 160):hi + 160]
        for rg in regs:
            snip = rg.sub(lambda m: f">>{m.group(0)}<<", snip)
        hits.append((r, snip))
    return hits[:limit], groups, len(hits)

# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="*")
    ap.add_argument("-f", "--fuzzy", action="store_true", help="sound-alike / spelling-variant search")
    ap.add_argument("--window", type=int, default=60, help="fuzzy: max characters spanned by all words (default 60)")
    ap.add_argument("--like", action="store_true")
    ap.add_argument("--page", nargs=2, type=int, metavar=("PART", "PAGE"))
    ap.add_argument("--part", type=int)
    ap.add_argument("--limit", type=int, default=20)
    ap.add_argument("--db", default=DB)
    a = ap.parse_args()
    db = sqlite3.connect(a.db); db.row_factory = sqlite3.Row
    J = "JOIN parts USING(part)"
    if a.page:
        r = db.execute(f"SELECT pages.*, file_name, vault_url FROM pages {J} WHERE part=? AND page=?", a.page).fetchone()
        if not r: sys.exit("No such page.")
        print(cite(r)); print("-" * 80); print(r["text"]); return
    q = " ".join(a.query)
    if not q: ap.print_help(); return

    def show_fuzzy(note=""):
        words = re.findall(r"[\w'|$€!]+", q)
        hits, groups, total = fuzzy_search(db, words, a.window, a.part, a.limit)
        print(note + "Sound-alike search. Spellings searched:")
        for w, v in groups:
            print(f"  {w}: " + ", ".join(f"{t} ({n}p)" for t, n, _ in v))
        print(f"\n{total} matching pages (showing {len(hits)})\n")
        for r, snip in hits:
            print(cite(r))
            print(textwrap.indent(textwrap.fill(" ".join(snip.split()), 110), "    "))
            print()

    if a.fuzzy:
        return show_fuzzy()
    extra = " AND pages.part=?" if a.part else ""
    args = [q] + ([a.part] if a.part else []) + [a.limit]
    if a.like:
        sql = (f"SELECT pages.*, file_name, vault_url, substr(text, max(1,instr(lower(text),lower(?1))-150), 350) AS snip "
               f"FROM pages {J} WHERE instr(lower(text),lower(?1))>0{extra} ORDER BY part,page LIMIT ?")
    else:
        sql = (f"SELECT pages.*, file_name, vault_url, snippet(pages_fts,0,'>>','<<',' … ',40) AS snip "
               f"FROM pages_fts JOIN pages ON pages.id=pages_fts.rowid {J} "
               f"WHERE pages_fts MATCH ?{extra} ORDER BY rank LIMIT ?")
    try:
        rows = db.execute(sql, args).fetchall()
        total = len(rows) if a.like else db.execute(
            "SELECT count(*) FROM pages_fts WHERE pages_fts MATCH ?", [q]).fetchone()[0]
    except sqlite3.OperationalError:
        rows, total = [], 0
    if total == 0 and not a.like:
        return show_fuzzy("No exact matches. ")
    print(f"{total} matching pages (showing {len(rows)})\n")
    for r in rows:
        print(cite(r))
        print(textwrap.indent(textwrap.fill(" ".join(r["snip"].split()), 110), "    "))
        print()

if __name__ == "__main__":
    main()
